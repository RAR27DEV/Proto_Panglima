<?php
/**
 * Konfigurasi UJI COBA LOKAL (SQLite, tanpa perlu server database).
 *
 * Di hosting Rumahweb, ganti isi file ini memakai contoh di
 * config.example.php  ->  db_driver 'mysql' + kredensial cPanel.
 *
 * File ini tidak ikut ke GitHub (sudah ada di .gitignore).
 */

return [
    // 'sqlite' = uji lokal · 'mysql' = hosting Rumahweb
    'db_driver' => 'sqlite',
    'db_file'   => __DIR__ . '/../data/tokopanglima.sqlite',

    // Dipakai saat db_driver = 'mysql'
    'db_host' => 'localhost',
    'db_name' => '',
    'db_user' => '',
    'db_pass' => '',

    // Lokal pakai http biasa, jadi jangan paksa https di sini.
    'force_https' => false,

    'session_name'         => 'TPSESS',
    'session_idle_timeout' => 8 * 60 * 60,
    'max_login_attempts'   => 5,
    'lockout_minutes'      => 15,
];
